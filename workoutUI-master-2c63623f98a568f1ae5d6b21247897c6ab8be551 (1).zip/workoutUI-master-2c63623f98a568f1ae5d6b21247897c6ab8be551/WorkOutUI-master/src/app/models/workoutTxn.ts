import { Workout } from './workout'; 

export class WorkoutTxn {
    startTime: String ;
    stopTime: String ;
    duration: number;
    calBurnt: string;
    workout: Workout;
  }