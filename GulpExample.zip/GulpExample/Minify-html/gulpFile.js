var gulp=require('gulp');
var minifyHtml=require('gulp-minify-html');

gulp.task('minify-html',function(){
	gulp.src('./html/*.html')//path to files
	.pipe(minifyHtml())
	.pipe(gulp.dest('./dist/minified'));
});

//to run : gulp minify-html