'use strict';

module.exports = function(app) {
  var todoList = require('../controllers/todoListController');
  var workoutController = require('../controllers/workoutController');

  var jsondata={
	   "user1" : {
		  "name" : "mahesh",
		  "password" : "password1",
		  "profession" : "teacher",
		  "id": 1
	   },
	   "user2" : {
		  "name" : "suresh",
		  "password" : "password2",
		  "profession" : "librarian",
		  "id": 2
	   },
	   "user3" : {
		  "name" : "ramesh",
		  "password" : "password3",
		  "profession" : "clerk",
		  "id": 3
	   }
  };

  app.get("/", function(req, res) {
		res.status(200).send("Welcome to our restful API");
  });
  	

  app.route('/category')
    .get(workoutController.list_all_categories)
    .post(workoutController.create_category);
	
  app.route('/category/:categoryId')
    .get(workoutController.read_a_category)
    .put(workoutController.update_a_category)
	.delete(workoutController.delete_a_category);

  app.route('/workouts')
    .get(workoutController.list_all_workouts)
    .post(workoutController.create_workout);
	
  app.route('/workouts/:workoutId')
    .get(workoutController.read_a_workout)
    .put(workoutController.update_a_workout)
    .delete(workoutController.delete_a_workout);
	
/*  app.route('/workoutActive')
    .get(workoutController.list_all_workoutActive)
    .post(workoutController.create_workoutActive);
	
  app.route('/workoutActive/:workoutActiveId')
    .get(workoutController.read_workoutActive)
    .put(workoutController.update_workoutActive)
    .delete(workoutController.delete_workoutActive);*/
	
  // todoList Routes
  app.route('/tasks')
    .get(todoList.list_all_tasks)
    .post(todoList.create_a_task);

  app.route('/tasks/:taskId')
    .get(todoList.read_a_task)
    .put(todoList.update_a_task)
    .delete(todoList.delete_a_task);
};