'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var workoutCategorySchema = new Schema({        
	categoryId: mongoose.Schema.Types.ObjectId,	
	categoryName: {
		type: String,
		required: 'Category is required'
	},
	createdDt: {
		type: Date,
		default: Date.now
	}
});

module.exports = mongoose.model('WorkoutCategory', workoutCategorySchema);
