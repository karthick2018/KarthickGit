'use strict';
var mongoose = require('mongoose');
var Schema = mongoose.Schema;

var workoutSchema = new Schema({
    workoutId: mongoose.Schema.Types.ObjectId,
    workoutTitle: String,
    workoutNote: String,
    caloriesBurnPerMin: Number,   
    workoutCategory:{
        type: mongoose.Schema.Types.ObjectId,
        ref: 'WorkoutCategory'
    },
    workoutActive: [
      {
        type: mongoose.Schema.Types.ObjectId,
        ref: 'WorkoutActive'
      }
    ],
    createdDt: {
        type: Date,
        default: Date.now
	}
}); 

module.exports = mongoose.model('Workouts', workoutSchema);