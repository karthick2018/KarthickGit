'use strict';

module.exports = function(app) {
  var todoList = require('../controllers/todoListController');
  var workoutController = require('../controllers/workoutController');
  
  app.get("/", function(req, res) {
		res.status(200).send("Welcome to our restful API");
  });
  	

  app.route('/category')
    .get(workoutController.list_all_categories)
    .post(workoutController.create_category);
	
  app.route('/category/:categoryId')
    .get(todoList.read_a_category)
    .put(todoList.update_a_category)
	.delete(todoList.delete_a_category);

  app.route('/workouts')
    .get(workoutController.list_all_workouts)
    .post(workoutController.create_workout);
	
  app.route('/workouts/:workoutId')
    .get(todoList.read_a_workout)
    .put(todoList.update_a_workout)
    .delete(todoList.delete_a_workout);
	
	 app.route('/workoutActive')
    .get(workoutController.list_all_workoutActive)
    .post(workoutController.create_workoutActive);
	
  app.route('/workoutActive/:workoutActiveId')
    .get(todoList.read_workoutActive)
    .put(todoList.update_workoutActive)
    .delete(todoList.delete_workoutActive);
	
  // todoList Routes
  app.route('/tasks')
    .get(todoList.list_all_tasks)
    .post(todoList.create_a_task);

  app.route('/tasks/:taskId')
    .get(todoList.read_a_task)
    .put(todoList.update_a_task)
    .delete(todoList.delete_a_task);
};