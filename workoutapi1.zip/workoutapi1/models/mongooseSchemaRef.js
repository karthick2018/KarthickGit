'use strict';
var mongoose = require('mongoose');
var Schema=mongoose.Schema;


var TaskSchema = new Schema({
  name: {
    type: String,
    required: 'Kindly enter the name of the task'
  },
  Created_date: {
    type: Date,
    default: Date.now
  },
  status: {
    type: [{
      type: String,
      enum: ['pending', 'ongoing', 'completed']
    }],
    default: ['pending']
  }
});

var WorkoutSchema = Schema({
    workoutId: mongoose.Schema.Types.ObjectId,
    workoutTitle: String,
    workoutNote: String,
    caloriesBurnPerMin: Number, 
	category:{type:Schema.Types.Object,ref:"WorkoutCategory"},
	workoutActive:{type:Schema.Types.Object,ref:"WorkoutActive"},
    createdDt: {type: Date,default: Date.now}
}); 

var WorkoutActiveSchema = Schema({        
    workoutActiveId: mongoose.Schema.Types.ObjectId,
	startDateTime: Date,                                     
    endDateTime: Date   
});

var WorkoutCategorySchema =  Schema({        
	categoryId: mongoose.Schema.Types.ObjectId,	
	categoryName: {type: String, required: 'Category is required'},
	createdDt: {type: Date,default: Date.now}
});

var Workout=mongoose.model('Workout',WorkoutSchema);
var WorkoutActive=mongoose.model('WorkoutActive',WorkoutActiveSchema);
var WorkoutCategory=mongoose.model('WorkoutCategory',WorkoutCategorySchema);

var TaskK = mongoose.model('TasksK', TaskSchema); 
module.exports.TaskK=TaskK;

module.exports.Workout = Workout;
module.exports.WorkoutActive = WorkoutActive;
module.exports.WorkoutCategory = WorkoutCategory;

