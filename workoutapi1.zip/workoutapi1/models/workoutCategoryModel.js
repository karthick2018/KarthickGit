'use strict';
var mongoose = require('mongoose');

var workoutCategorySchema = new mongoose.Schema({        
	categoryId: mongoose.Schema.Types.ObjectId,	
	categoryName: {
		type: String,
		required: 'Category is required'
	},
	createdDt: {
		type: Date,
		default: Date.now
	}
});

module.exports.workoutCategorySchema = workoutCategorySchema;

/*var WorkoutCategory = mongoose.model('WorkoutCategory', workoutCategorySchema);
module.exports = WorkoutCategory;*/
