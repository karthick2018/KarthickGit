package com.workoutportal.User;

public enum UnitTime {

	HOUR, MINUTE, SECOND

}
