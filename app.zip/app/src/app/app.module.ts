import { NgModule }      from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { RouterModule, Routes } from '@angular/router';
import { HttpClientModule } from '@angular/common/http';
import { FormsModule }      from '@angular/forms';


import { AppComponent }  from './app.component';

import { ViewAllWorkoutComponent }  from './components/viewAllWorkout.component';
import { StartEndWorkComponent }  from './components/startEndWork.component';

import { WorkoutComponent }  from './components/workoutComponent.component';
import { CategoryComponent }  from './components/category.component';
import { TrackWorkoutComponent }  from './components/trackWorkout.component';

import { PageNotFoundComponent }  from './components/pageNotFound.component';
import { CategoryPipe} from './components/pipe/category.pipe';
import { WorkoutPipe} from './components/pipe/workout.pipe';

const appRoutes: Routes = [
  { path: 'ViewAllWorkout', component: ViewAllWorkoutComponent },
  { path: 'StartWorkout/:page', component: StartEndWorkComponent,data: { page: 'StartWorkout' }},
  { path: 'EndWorkout/:page', component: StartEndWorkComponent,data: { page: 'EndWorkout' } },
  { path: 'EditWorkout/:id',component: WorkoutComponent,data: { page: 'EditWorkout' } },
  { path: 'AddWorkout', component: WorkoutComponent,data: { page: 'AddWorkout' } },
  
  { path: 'Category', component: CategoryComponent },
  { path: 'Track', component: TrackWorkoutComponent },
  { path: '', redirectTo: '/ViewAllWorkout', pathMatch: 'full' },
  { path: '**', component: PageNotFoundComponent }
];



@NgModule({
  imports:[ BrowserModule,FormsModule,
    HttpClientModule,
	RouterModule.forRoot(appRoutes,{ enableTracing: true } // <-- debugging purposes only
    )
  ],
  declarations: [ AppComponent,CategoryPipe,WorkoutPipe, ViewAllWorkoutComponent,StartEndWorkComponent,WorkoutComponent,CategoryComponent,TrackWorkoutComponent,PageNotFoundComponent],
  bootstrap:    [ AppComponent ]
})
export class AppModule { }
