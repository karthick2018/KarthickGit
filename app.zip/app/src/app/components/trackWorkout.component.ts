import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  templateUrl: './track.component.html',
  styleUrls: ['./public/css/app.css']
})
export class TrackWorkoutComponent { }