import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError, retry, map, tap } from 'rxjs/operators';

import { Category} from '../model/Category';
import {Config} from '../model/Config';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable()
export class CategoryService {
 
	private getAllCategoriesUrl = 'http://user1-PC:3002/Category/';// URL to web api
	private updateCategoryUrl = 'http://user1-PC:3002/Category';// URL to web api
	private saveCategoryUrl = 'http://user1-PC:3002/Category/';// URL to web api
	private deleteCategoryUrl = 'http://user1-PC:3002/Category';// URL to web api
	
	categories:Category[];
  
    constructor(private http: HttpClient) { }

	configUrl = 'assets/config.json';
	config: Config;	
		  
	/** GET Categories from the Rest API server */
	getAllCategories (): Observable<Category[]> {
	  return this.http.get<Category[]>(this.getAllCategoriesUrl).pipe(
		  tap(categories => console.log(categories)),
		  catchError(this.handleError('getAllCategoriesHttp', []))
		);
	}

	/** PUT: update the Category on the server */
	updateCategory (category:Category): Observable<any> {
	   const url = `${this.deleteCategoryUrl}/${category._id}`;
	   console.log("category url....."+url);
	   return this.http.put(url, category, httpOptions).pipe(
		 tap(_ => console.log(`updated category id=${category._id}`)),
		 catchError(this.handleError<any>('updateCategory'))
	   );
	}	
		
	/** POST: add a new Category to the server */
	saveCategory (category:Category): Observable<Category> {
		console.log("category"+category);
		return this.http.post<Category>(this.saveCategoryUrl, category, httpOptions).pipe(
			tap((category:Category) => console.log('added category ')),
			catchError(this.handleError<Category>('Save Category'))
		);
	}
	//w/ id=${category._id}
	/** DELETE: delete the Category from the server */
	deleteCategory(category:Category): Observable<any> {
	    const url = `${this.deleteCategoryUrl}/${category._id}`;
	    console.log("category url....."+url);	
	    return this.http.delete<Category>(url, httpOptions).pipe(
		tap(_ => console.log('Deleted Category successfully')),
		catchError(this.handleError<Category>('Delete Category'))
	  );
	}		
	
  
	/**
	* Handle Http operation that failed.
	* Let the app continue.
	* @param operation - name of the operation that failed
	* @param result - optional value to return as the observable result
	*/
	private handleError<T> (operation = 'operation', result?: T) {		
		return (error: any): Observable<T> => {
			// TODO: send the error to remote logging infrastructure			
			console.log('${error.message}'); // log to console instead

			// TODO: better job of transforming error for user consumption
			console.log(`${operation} failed: ${error.message}`);

			// Let the app keep running by returning an empty result.
			return of(result as T);
		};
	}

}