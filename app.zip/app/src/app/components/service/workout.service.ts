import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';
import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';

import { catchError, retry, map, tap } from 'rxjs/operators';


import {Category} from '../model/Category';
import {Workout} from '../model/Workout';
import {WorkoutActive} from '../model/WorkoutActive';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable()
export class WorkoutService {
 
	private getAllWorkoutsUrl = 'http://user1-PC:3002/workouts/';// URL to web api
	private updateWorkoutUrl = 'http://user1-PC:3002/workouts';// URL to web api
	private saveWorkoutUrl = 'http://user1-PC:3002/workouts/';// URL to web api
	private deleteWorkoutUrl = 'http://user1-PC:3002/workouts';// URL to web api
	private getWorkoutsUrl = 'http://user1-PC:3002/workouts';// URL to web api
	
	categories:Category[];		
	workouts:Workout[];
  
    constructor(private http: HttpClient) { }

	getAllWorkoutsHttp(): Observable<Workout[]>{	
		return of(this.workouts);
	}
		  
	/** GET Workout from the Rest API server */
	getAllWorkouts (): Observable<Workout[]> {
	  return this.http.get<Workout[]>(this.getAllWorkoutsUrl).pipe(
		  tap(workouts => console.log(`fetched Workout`)),
		  catchError(this.handleError('getAllWorkout', []))
		);
	}
	
	/** GET getWorkout by id. Will 404 if id not found */
	getWorkout(id: string): Observable<Workout> {
		console.log("id::::::::::::::"+id);
	  const url = `${this.getWorkoutsUrl}/${id}`;
	  return this.http.get<Workout>(url).pipe(
		tap(_ => console.log(`fetched Workout id=${id}`)),
		catchError(this.handleError<Hero>(`getWorkout id=${id}`))
	  );
	}


	/** PUT: update the Workout on the server */
	updateWorkout (workout:Workout): Observable<any> {
	  return this.http.put(this.updateWorkoutUrl, workout, httpOptions).pipe(
		tap(_ => console.log(`updated Workout id=${workout.workoutId}`)),
		catchError(this.handleError<any>('updateWorkout'))
	  );
	}	
		
	/** POST: add a new Workout to the server */
	saveWorkout (workout:Workout): Observable<Workout> {
		console.log("In Service:>>>>>>>>>>>"+JSON.stringify(workout));
		return this.http.post<Workout>(this.saveWorkoutUrl, workout, httpOptions).pipe(
			tap((workout:Workout) => console.log(`added Workout w/ id=${workout._id}`)),
			catchError(this.handleError<Workout>('Save Workout'))
		);
	}
	/** DELETE: delete the Workout from the server */
	deleteWorkout(workout:Workout | string): Observable<any> {
	  const workoutId = typeof workout === 'string' ? workout:workout._id;
	  const url = `${this.deleteWorkoutUrl}/${workoutId}`;	  
	  console.log("WorkoutId"+workoutId);	  
	  return this.http.delete<Workout>(url, httpOptions).pipe(
		tap(_ => console.log(`deleted Workout id=${workoutId}`)),
		catchError(this.handleError<Workout>('delete Workout'))
	  );
	}
	
	/**
	* Handle Http operation that failed.
	* Let the app continue.
	* @param operation - name of the operation that failed
	* @param result - optional value to return as the observable result
	*/
	private handleError<T> (operation = 'operation', result?: T) {
		return (error: any): Observable<T> => {
			// TODO: send the error to remote logging infrastructure
			console.error(error); // log to console instead

			// TODO: better job of transforming error for user consumption
			console.log(`${operation} failed: ${error.message}`);

			// Let the app keep running by returning an empty result.
			return of(result as T);
		};
	}

}
