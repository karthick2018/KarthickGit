import { Component } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Directive, OnInit, OnDestroy, Input } from '@angular/core';

import {Category} from './model/Category';
import {Workout} from './model/Workout';
import {WorkoutActive} from './model/WorkoutActive';

import { CategoryService } from './service/category.service';
import { WorkoutService } from './service/workout.service';

@Component({
  selector: 'app-root',
  templateUrl: './createWorkout.component.html',  
  providers: [ CategoryService,WorkoutService ],
  styleUrls: ['./public/css/app.css']
})
export class WorkoutComponent  implements OnInit {	
    selectedCategory:Category;
	categories:Category[];
  
	workoutId:string;
	workoutPageType:string;
	workoutPageAction:string;
	//workout= Workout("123","Karthick","notes",parseInt('0644',1),"catid" );
	workout=new Workout();
	isEditWorkout:boolean;
	
	ngOnInit() {
		this.getAllCategories();		
		this.isEditWorkout=false;				
		this.workoutPageType="Create";
		this.workoutPageAction="Add";		
		
		this.workoutId = this.route.snapshot.paramMap.get('id');
		console.log("Id::::::: :"+this.workoutId);
		this.selectedCategory = new Category();
		this.selectedCategory._id='';
		this.selectedCategory.categoryName='Select Category';
		if(this.workoutId!=null){			
			this.isEditWorkout=true;
			this.workoutPageType="Edit";
			this.workoutPageAction="Update";			
			this.getWorkout(this.workoutId);
			
			if(this.workout.category!=null){
				console.log('--------------->'+this.workout.category.categoryName);
				this.selectedCategory.categoryName=this.workout.category.categoryName;
				this.selectedCategory._id=this.workout.category._id;
			}
		}
		console.log("this.workoutPageType:  "+this.workoutPageType);	
	}
	
	constructor(private router: Router,private route: ActivatedRoute, private categoryService:CategoryService,private workoutService:WorkoutService) { 
		this.route.params.subscribe(params => console.log(params) );
	}
	  
    //call service to list all available categories
    getAllCategories(): void {
	  this.categoryService.getAllCategories()
      .subscribe(categories => this.categories = categories);
    }
	/** GET getWorkout by id. Will 404 if id not found */
	getWorkout(id: string){	
	  this.workoutService.getWorkout(id)
      .subscribe(workout => this.workout = workout;);
	  );	  
	}
	
    //call service to save new Category
    addUpdateWorkout(): void {
	  console.log("this.workoutPageType:  "+this.workoutPageType);
	  if (!this.workoutPageType) { return; }	
	  if(this.workoutPageType=="Create"){		
		//this.workout=new Workout();
		console.log("work out details:  "+this.workout.workoutTitle);
		console.log(this.workout.workoutNotes);
		console.log(this.workout.caloriesBurntPerMin);
		//workoutCategory=new Category();		
		//workoutCategory._id=this.selectedCategory._id;
		this.workout.category=this.selectedCategory;
		
		this.workoutService.saveWorkout(this.workout)
			  .subscribe(category => {				   
				  console.log("Workout Saved");
				  this.router.navigate(['/ViewAllWorkout']);				  
			  });		  
	  }else{
		  
		   this.router.navigate(['/ViewAllWorkout']);
	  }
  }  
  
  
    aaddUpdateWorkout() {
		console.log("Workout id: "+this.workout._id);
		
        this.router.navigate(['/ViewAllWorkout']);
    }
	cancelWorkoutEdit() {
        this.router.navigate(['/ViewAllWorkout']);
    }
	addCategory() {
        this.router.navigate(['/Category']);
    }
	addCaloriesBurnt(){
		if(this.workout.caloriesBurntPerMin>0)
			this.workout.caloriesBurntPerMin=this.workout.caloriesBurntPerMin+10;
		else
			this.workout.caloriesBurntPerMin=10;
	}
	reduceCaloriesBurnt(){
		if(this.workout.caloriesBurntPerMin>10)
		  this.workout.caloriesBurntPerMin=this.workout.caloriesBurntPerMin-10;
	    else
		  this.workout.caloriesBurntPerMin=0;
	}
}
