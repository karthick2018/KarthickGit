"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var core_1 = require("@angular/core");
var platform_browser_1 = require("@angular/platform-browser");
var router_1 = require("@angular/router");
var http_1 = require("@angular/common/http");
var forms_1 = require("@angular/forms");
var app_component_1 = require("./app.component");
var viewAllWorkout_component_1 = require("./components/viewAllWorkout.component");
var startEndWork_component_1 = require("./components/startEndWork.component");
var workoutComponent_component_1 = require("./components/workoutComponent.component");
var category_component_1 = require("./components/category.component");
var trackWorkout_component_1 = require("./components/trackWorkout.component");
var pageNotFound_component_1 = require("./components/pageNotFound.component");
var category_pipe_1 = require("./components/pipe/category.pipe");
var workout_pipe_1 = require("./components/pipe/workout.pipe");
var appRoutes = [
    { path: 'ViewAllWorkout', component: viewAllWorkout_component_1.ViewAllWorkoutComponent },
    { path: 'StartWorkout/:page', component: startEndWork_component_1.StartEndWorkComponent, data: { page: 'StartWorkout' } },
    { path: 'EndWorkout/:page', component: startEndWork_component_1.StartEndWorkComponent, data: { page: 'EndWorkout' } },
    { path: 'EditWorkout/:id', component: workoutComponent_component_1.WorkoutComponent, data: { page: 'EditWorkout' } },
    { path: 'AddWorkout', component: workoutComponent_component_1.WorkoutComponent, data: { page: 'AddWorkout' } },
    { path: 'Category', component: category_component_1.CategoryComponent },
    { path: 'Track', component: trackWorkout_component_1.TrackWorkoutComponent },
    { path: '', redirectTo: '/ViewAllWorkout', pathMatch: 'full' },
    { path: '**', component: pageNotFound_component_1.PageNotFoundComponent }
];
var AppModule = (function () {
    function AppModule() {
    }
    return AppModule;
}());
AppModule = __decorate([
    core_1.NgModule({
        imports: [platform_browser_1.BrowserModule, forms_1.FormsModule,
            http_1.HttpClientModule,
            router_1.RouterModule.forRoot(appRoutes, { enableTracing: true } // <-- debugging purposes only
            )
        ],
        declarations: [app_component_1.AppComponent, category_pipe_1.CategoryPipe, workout_pipe_1.WorkoutPipe, viewAllWorkout_component_1.ViewAllWorkoutComponent, startEndWork_component_1.StartEndWorkComponent, workoutComponent_component_1.WorkoutComponent, category_component_1.CategoryComponent, trackWorkout_component_1.TrackWorkoutComponent, pageNotFound_component_1.PageNotFoundComponent],
        bootstrap: [app_component_1.AppComponent]
    })
], AppModule);
exports.AppModule = AppModule;
//# sourceMappingURL=app.module.js.map