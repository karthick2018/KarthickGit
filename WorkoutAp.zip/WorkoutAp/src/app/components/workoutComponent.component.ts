import { Component } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';
import { Directive, OnInit, OnDestroy, Input } from '@angular/core';

import {Category} from './model/Category';
import {Workout} from './model/Workout';
import {WorkoutActive} from './model/WorkoutActive';

import { CategoryService } from './service/category.service';
import { WorkoutService } from './service/workout.service';

@Component({
  selector: 'app-root',
  templateUrl: './createWorkout.component.html',  
  providers: [ CategoryService,WorkoutService ],
  styleUrls: ['./public/css/app.css']
})
export class WorkoutComponent  implements OnInit {	
    selectedCategory:Category;
	categories:Category[];
  
	workoutId:string;
	workoutPageType:string;
	workoutPageAction:string;
	workout=new Workout("123","Karthick","notes",parseInt('0644',1),"catid" );
	isEditWorkout:boolean;
	
	ngOnInit() {
		this.getAllCategories();		
		this.isEditWorkout=false;				
		this.workoutPageType="Create";
		this.workoutPageAction="Add";
		this.workout.caloriesBurntPerMin=0;
		
		this.workoutId = this.route.snapshot.paramMap.get('id');
		console.log("Id::::::: :"+this.workoutId);
		this.selectedCategory = new Category('', 'Select Category');
		if(this.workoutId!=null){			
			this.selectedCategory = new Category('2', 'India');
			this.isEditWorkout=true;
			this.workoutPageType="Edit";
			this.workoutPageAction="Update";
		}
	}
	
	constructor(private router: Router,private route: ActivatedRoute, private categoryService:CategoryService,private workoutService:WorkoutService) { 
		this.route.params.subscribe(params => console.log(params) );
	}
	getAllCategories(): void {
	  this.categoryService.getAllCategories()
      .subscribe(categories => this.categories = categories);
  }
  
  //call service to list all available categories
  getAllCategoriesHttp(): void {
	  this.categoryService.getAllCategoriesHttp()
      .subscribe(categories => this.categories = categories);
  }
  
    addUpdateWorkout() {
		console.log("Workout id: "+this.workout.workoutId);
		
        this.router.navigate(['/ViewAllWorkout']);
    }
	cancelWorkoutEdit() {
        this.router.navigate(['/ViewAllWorkout']);
    }
	addCategory() {
        this.router.navigate(['/Category']);
    }
	addCaloriesBurnt(){
		if(this.workout.caloriesBurntPerMin>0)
			this.workout.caloriesBurntPerMin=this.workout.caloriesBurntPerMin+10;
		else
			this.workout.caloriesBurntPerMin=10;
	}
	reduceCaloriesBurnt(){
		if(this.workout.caloriesBurntPerMin>10)
		  this.workout.caloriesBurntPerMin=this.workout.caloriesBurntPerMin-10;
	    else
		  this.workout.caloriesBurntPerMin=0;
	}
}
