"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var category_service_1 = require("./service/category.service");
var Category_1 = require("./model/Category");
var CategoryComponent = (function () {
    function CategoryComponent(categoryService) {
        this.categoryService = categoryService;
        this.category = new Category_1.Category("", "");
    }
    CategoryComponent.prototype.ngOnInit = function () {
        this.getAllCategories();
    };
    CategoryComponent.prototype.getAllCategories = function () {
        var _this = this;
        this.categoryService.getAllCategories()
            .subscribe(function (categories) { return _this.categories = categories; });
    };
    //call service to list all available categories
    CategoryComponent.prototype.getAllCategoriesHttp = function () {
        var _this = this;
        this.categoryService.getAllCategoriesHttp()
            .subscribe(function (categories) { return _this.categories = categories; });
    };
    //call service to update Category
    CategoryComponent.prototype.updateCategoryHttp = function (category) {
        console.log(category.categoryName);
        this.categoryService.updateCategory(category)
            .subscribe(function () { return console.log("go back"); });
    };
    //call service to save new Category
    CategoryComponent.prototype.addCategoryHttp = function () {
        if (this.newCategoryName != null && this.newCategoryName != "") {
            this.category = new Category_1.Category("", this.newCategoryName);
            this.categoryService.saveCategory(this.category);
            this.getAllCategories();
            this.newCategoryName = "";
        }
    };
    CategoryComponent.prototype.deleteCategory = function (category) {
        console.log("Category ID Name To delete " + category.categoryId + " " + category.categoryName);
        //this.category = this.categories.filter(h => h !== category);
        this.categoryService.deleteCategory(category).subscribe();
    };
    CategoryComponent.prototype.updateCategory = function (category) {
        console.log(category.categoryName);
    };
    CategoryComponent.prototype.addCategory = function () {
        if (this.newCategoryName != null && this.newCategoryName != "") {
            this.category = new Category_1.Category("", this.newCategoryName);
            this.newCategoryName = "Added";
        }
    };
    CategoryComponent.prototype.deleteCategoryH = function (categoryId) {
        this.newCategoryName = categoryId;
    };
    return CategoryComponent;
}());
CategoryComponent = __decorate([
    core_1.Component({
        selector: 'app-category',
        templateUrl: './category.component.html',
        providers: [category_service_1.CategoryService],
        styleUrls: ['./public/css/app.css']
    }),
    __metadata("design:paramtypes", [category_service_1.CategoryService])
], CategoryComponent);
exports.CategoryComponent = CategoryComponent;
//# sourceMappingURL=category.component.js.map