"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var router_1 = require("@angular/router");
var Category_1 = require("./model/Category");
var Workout_1 = require("./model/Workout");
var category_service_1 = require("./service/category.service");
var workout_service_1 = require("./service/workout.service");
var WorkoutComponent = (function () {
    function WorkoutComponent(router, route, categoryService, workoutService) {
        this.router = router;
        this.route = route;
        this.categoryService = categoryService;
        this.workoutService = workoutService;
        this.workout = new Workout_1.Workout("123", "Karthick", "notes", parseInt('0644', 1), "catid");
        this.route.params.subscribe(function (params) { return console.log(params); });
    }
    WorkoutComponent.prototype.ngOnInit = function () {
        this.getAllCategories();
        this.isEditWorkout = false;
        this.workoutPageType = "Create";
        this.workoutPageAction = "Add";
        this.workout.caloriesBurntPerMin = 0;
        this.workoutId = this.route.snapshot.paramMap.get('id');
        console.log("Id::::::: :" + this.workoutId);
        this.selectedCategory = new Category_1.Category('', 'Select Category');
        if (this.workoutId != null) {
            this.selectedCategory = new Category_1.Category('2', 'India');
            this.isEditWorkout = true;
            this.workoutPageType = "Edit";
            this.workoutPageAction = "Update";
        }
    };
    WorkoutComponent.prototype.getAllCategories = function () {
        var _this = this;
        this.categoryService.getAllCategories()
            .subscribe(function (categories) { return _this.categories = categories; });
    };
    //call service to list all available categories
    WorkoutComponent.prototype.getAllCategoriesHttp = function () {
        var _this = this;
        this.categoryService.getAllCategoriesHttp()
            .subscribe(function (categories) { return _this.categories = categories; });
    };
    WorkoutComponent.prototype.addUpdateWorkout = function () {
        console.log("Workout id: " + this.workout.workoutId);
        this.router.navigate(['/ViewAllWorkout']);
    };
    WorkoutComponent.prototype.cancelWorkoutEdit = function () {
        this.router.navigate(['/ViewAllWorkout']);
    };
    WorkoutComponent.prototype.addCategory = function () {
        this.router.navigate(['/Category']);
    };
    WorkoutComponent.prototype.addCaloriesBurnt = function () {
        if (this.workout.caloriesBurntPerMin > 0)
            this.workout.caloriesBurntPerMin = this.workout.caloriesBurntPerMin + 10;
        else
            this.workout.caloriesBurntPerMin = 10;
    };
    WorkoutComponent.prototype.reduceCaloriesBurnt = function () {
        if (this.workout.caloriesBurntPerMin > 10)
            this.workout.caloriesBurntPerMin = this.workout.caloriesBurntPerMin - 10;
        else
            this.workout.caloriesBurntPerMin = 0;
    };
    return WorkoutComponent;
}());
WorkoutComponent = __decorate([
    core_1.Component({
        selector: 'app-root',
        templateUrl: './createWorkout.component.html',
        providers: [category_service_1.CategoryService, workout_service_1.WorkoutService],
        styleUrls: ['./public/css/app.css']
    }),
    __metadata("design:paramtypes", [router_1.Router, router_1.ActivatedRoute, category_service_1.CategoryService, workout_service_1.WorkoutService])
], WorkoutComponent);
exports.WorkoutComponent = WorkoutComponent;
//# sourceMappingURL=workoutComponent.component.js.map