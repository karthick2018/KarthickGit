"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/common/http");
var of_1 = require("rxjs/observable/of");
var operators_1 = require("rxjs/operators");
var Category_1 = require("../model/Category");
var httpOptions = {
    headers: new http_1.HttpHeaders({ 'Content-Type': 'application/json' })
};
var CategoryService = (function () {
    function CategoryService(http) {
        this.http = http;
        this.getAllCategoriesUrl = 'api/Category'; // URL to web api
        this.updateCategoryUrl = 'api/Category'; // URL to web api
        this.saveCategoryUrl = 'api/Category'; // URL to web api
        this.deleteCategoryUrl = 'api/Category'; // URL to web api
        this.categories = [
            new Category_1.Category("1", 'KarthickTesting'),
            new Category_1.Category("13", 'Bombasto'),
            new Category_1.Category("15", 'Magneta'),
            new Category_1.Category("20", 'Tornado')
        ];
        this.configUrl = 'assets/config.json';
    }
    CategoryService.prototype.getAllCategories = function () {
        return of_1.of(this.categories);
    };
    /* AddCategory(item:any):Observable<string> {
         //include httpOptions
       return this._http.post("http://localhost:3001/Category",item)
       .map((response:Response)=><string>response.json())
     }
     GetCategories():Observable<Category[]>
     {
       return  this._http.get("http://localhost: 3001//Category")
       .map((response:Response)=><Category[]>response.json())
     }*/
    /** GET Categories from the Rest API server */
    CategoryService.prototype.getAllCategoriesHttp = function () {
        return this.http.get(this.getAllCategoriesUrl).pipe(operators_1.tap(function (categories) { return console.log("fetched categories"); }), operators_1.catchError(this.handleError('getAllCategoriesHttp', [])));
    };
    /** PUT: update the Category on the server */
    CategoryService.prototype.updateCategory = function (category) {
        return this.http.put(this.updateCategoryUrl, category, httpOptions).pipe(operators_1.tap(function (_) { return console.log("updated category id=" + category.categoryId); }), operators_1.catchError(this.handleError('updateCategory')));
    };
    /** POST: add a new Category to the server */
    CategoryService.prototype.saveCategory = function (category) {
        console.log(category.categoryName);
        return this.http.post(this.saveCategoryUrl, category, httpOptions).pipe(operators_1.tap(function (category) { return console.log("added category w/ id=" + category.categoryId); }), operators_1.catchError(this.handleError('Save Category')));
    };
    /** DELETE: delete the Category from the server */
    CategoryService.prototype.deleteCategory = function (category) {
        var categoryId = typeof category === 'string' ? category : category.categoryId;
        var url = this.deleteCategoryUrl + "/" + categoryId;
        console.log("categoryId" + categoryId);
        return this.http.delete(url, httpOptions).pipe(operators_1.tap(function (_) { return console.log("deleted Category id=" + categoryId); }), operators_1.catchError(this.handleError('delete Category')));
    };
    /**
    * Handle Http operation that failed.
    * Let the app continue.
    * @param operation - name of the operation that failed
    * @param result - optional value to return as the observable result
    */
    CategoryService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // TODO: better job of transforming error for user consumption
            console.log(operation + " failed: " + error.message);
            // Let the app keep running by returning an empty result.
            return of_1.of(result);
        };
    };
    return CategoryService;
}());
CategoryService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.HttpClient])
], CategoryService);
exports.CategoryService = CategoryService;
//# sourceMappingURL=category.service.js.map