import { Injectable } from '@angular/core';
import { HttpClient, HttpHeaders } from '@angular/common/http';
import { HttpErrorResponse, HttpResponse } from '@angular/common/http';

import { Observable } from 'rxjs/Observable';
import { of } from 'rxjs/observable/of';
import { ErrorObservable } from 'rxjs/observable/ErrorObservable';
import { catchError, retry, map, tap } from 'rxjs/operators';

import { Category} from '../model/Category';
import {Config} from '../model/Config';

const httpOptions = {
  headers: new HttpHeaders({ 'Content-Type': 'application/json' })
};


@Injectable()
export class CategoryService {
 
	private getAllCategoriesUrl = 'api/Category';// URL to web api
	private updateCategoryUrl = 'api/Category';// URL to web api
	private saveCategoryUrl = 'api/Category';// URL to web api
	private deleteCategoryUrl = 'api/Category';// URL to web api
	
	categories = [
		new Category("1", 'KarthickTesting'),
		new Category("13", 'Bombasto'),
		new Category("15", 'Magneta'),
		new Category("20", 'Tornado')
	  ];
  
   constructor(private http: HttpClient) { }


	configUrl = 'assets/config.json';
	config: Config;	
	
	getAllCategories(): Observable<Category[]>{	
		return of(this.categories);
	}
	 /* AddCategory(item:any):Observable<string> {
		  //include httpOptions
		return this._http.post("http://localhost:3001/Category",item)
		.map((response:Response)=><string>response.json())  
	  }
	  GetCategories():Observable<Category[]>
	  {
		return  this._http.get("http://localhost: 3001//Category")
		.map((response:Response)=><Category[]>response.json())
	  }*/
	  
	/** GET Categories from the Rest API server */
	getAllCategoriesHttp (): Observable<Category[]> {
	  return this.http.get<Category[]>(this.getAllCategoriesUrl).pipe(
		  tap(categories => console.log(`fetched categories`)),
		  catchError(this.handleError('getAllCategoriesHttp', []))
		);
	}

	/** PUT: update the Category on the server */
	updateCategory (category:Category): Observable<any> {
	  return this.http.put(this.updateCategoryUrl, category, httpOptions).pipe(
		tap(_ => console.log(`updated category id=${category.categoryId}`)),
		catchError(this.handleError<any>('updateCategory'))
	  );
	}	
		
	/** POST: add a new Category to the server */
	saveCategory (category:Category): Observable<Category> {
		console.log(category.categoryName);
		return this.http.post<Category>(this.saveCategoryUrl, category, httpOptions).pipe(
			tap((category:Category) => console.log(`added category w/ id=${category.categoryId}`)),
			catchError(this.handleError<Category>('Save Category'))
		);
	}
	/** DELETE: delete the Category from the server */
	deleteCategory (category:Category | string): Observable<any> {
	  const categoryId = typeof category === 'string' ? category : category.categoryId;
	  const url = `${this.deleteCategoryUrl}/${categoryId}`;
	  
	  console.log("categoryId"+categoryId);	
	  
	  return this.http.delete<Category>(url, httpOptions).pipe(
		tap(_ => console.log(`deleted Category id=${categoryId}`)),
		catchError(this.handleError<Category>('delete Category'))
	  );
	}	
	
	/**
	* Handle Http operation that failed.
	* Let the app continue.
	* @param operation - name of the operation that failed
	* @param result - optional value to return as the observable result
	*/
	private handleError<T> (operation = 'operation', result?: T) {
		return (error: any): Observable<T> => {
			// TODO: send the error to remote logging infrastructure
			console.error(error); // log to console instead

			// TODO: better job of transforming error for user consumption
			console.log(`${operation} failed: ${error.message}`);

			// Let the app keep running by returning an empty result.
			return of(result as T);
		};
	}

}