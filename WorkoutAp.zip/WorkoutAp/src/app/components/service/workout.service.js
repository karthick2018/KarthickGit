"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var core_1 = require("@angular/core");
var http_1 = require("@angular/common/http");
var of_1 = require("rxjs/observable/of");
var operators_1 = require("rxjs/operators");
var Category_1 = require("../model/Category");
var Workout_1 = require("../model/Workout");
var httpOptions = {
    headers: new http_1.HttpHeaders({ 'Content-Type': 'application/json' })
};
var WorkoutService = (function () {
    function WorkoutService(http) {
        this.http = http;
        this.getAllWorkoutsUrl = 'api/Workout'; // URL to web api
        this.updateWorkoutUrl = 'api/Workout'; // URL to web api
        this.saveWorkoutUrl = 'api/Workout'; // URL to web api
        this.deleteWorkoutUrl = 'api/Workout'; // URL to web api
        this.categories = [
            new Category_1.Category("1", 'KarthickTesting'),
            new Category_1.Category("13", 'Bombasto'),
            new Category_1.Category("15", 'Magneta'),
            new Category_1.Category("20", 'Tornado')
        ];
        this.workouts = [
            new Workout_1.Workout("1", 'Running for 5min', "notes", parseInt('0644', 8), "asdf"),
            new Workout_1.Workout("2", 'Jogging for 10min', "notes", parseInt('0644', 8), "asdf")
        ];
    }
    WorkoutService.prototype.getAllWorkouts = function () {
        return of_1.of(this.workouts);
    };
    /** GET Workout from the Rest API server */
    WorkoutService.prototype.getAllWorkoutHttp = function () {
        return this.http.get(this.getAllWorkoutsUrl).pipe(operators_1.tap(function (workouts) { return console.log("fetched Workout"); }), operators_1.catchError(this.handleError('getAllWorkoutHttp', [])));
    };
    /** PUT: update the Workout on the server */
    WorkoutService.prototype.updateWorkout = function (workout) {
        return this.http.put(this.updateWorkoutUrl, workout, httpOptions).pipe(operators_1.tap(function (_) { return console.log("updated Workout id=" + workout.workoutId); }), operators_1.catchError(this.handleError('updateWorkout')));
    };
    /** POST: add a new Workout to the server */
    WorkoutService.prototype.saveWorkout = function (workout) {
        console.log(workout.workoutTitle);
        return this.http.post(this.saveWorkoutUrl, workout, httpOptions).pipe(operators_1.tap(function (workout) { return console.log("added Workout w/ id=" + workout.workoutId); }), operators_1.catchError(this.handleError('Save Workout')));
    };
    /** DELETE: delete the Workout from the server */
    WorkoutService.prototype.deleteWorkout = function (workout) {
        var workoutId = typeof workout === 'string' ? workout : workout.workoutId;
        var url = this.deleteWorkoutUrl + "/" + workoutId;
        console.log("WorkoutId" + workoutId);
        return this.http.delete(url, httpOptions).pipe(operators_1.tap(function (_) { return console.log("deleted Workout id=" + workoutId); }), operators_1.catchError(this.handleError('delete Workout')));
    };
    /**
    * Handle Http operation that failed.
    * Let the app continue.
    * @param operation - name of the operation that failed
    * @param result - optional value to return as the observable result
    */
    WorkoutService.prototype.handleError = function (operation, result) {
        if (operation === void 0) { operation = 'operation'; }
        return function (error) {
            // TODO: send the error to remote logging infrastructure
            console.error(error); // log to console instead
            // TODO: better job of transforming error for user consumption
            console.log(operation + " failed: " + error.message);
            // Let the app keep running by returning an empty result.
            return of_1.of(result);
        };
    };
    return WorkoutService;
}());
WorkoutService = __decorate([
    core_1.Injectable(),
    __metadata("design:paramtypes", [http_1.HttpClient])
], WorkoutService);
exports.WorkoutService = WorkoutService;
//# sourceMappingURL=workout.service.js.map