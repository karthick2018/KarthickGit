"use strict";
var Workout = (function () {
    function Workout(id, workoutTit, notes, calBurnt, catid) {
        this.id = id;
        this.workoutTit = workoutTit;
        this.notes = notes;
        this.calBurnt = calBurnt;
        this.catid = catid;
        this.workoutId = id;
        this.workoutTitle = workoutTit;
        this.workoutNotes = notes;
        this.caloriesBurntPerMin = calBurnt;
        this.categoryId = catid;
    }
    return Workout;
}());
exports.Workout = Workout;
//# sourceMappingURL=Workout.js.map