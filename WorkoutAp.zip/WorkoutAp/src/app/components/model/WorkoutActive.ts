
export class WorkoutActive {
  workoutId: string;
  workoutActiveId: string;
  workoutTitle: string;
  workoutComments:string;
  workoutNotes: string;  
  startDateTime: string;  
  endDateTime: string;
  startDateTm: Date;  
  endDateTm: Date;
}