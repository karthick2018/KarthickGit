"use strict";
var Workout = (function () {
    function Workout() {
    }
    return Workout;
}());
exports.Workout = Workout;
//# sourceMappingURL=Workout_2.js.map