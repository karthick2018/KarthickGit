export class Category {
	constructor(public id: string,  public nm: string) { 
		this.categoryId=id;
		this.categoryName=nm;
	}	
    categoryId: string;	
    categoryName: string;
}