"use strict";
var Category = (function () {
    function Category(id, nm) {
        this.id = id;
        this.nm = nm;
        this.categoryId = id;
        this.categoryName = nm;
    }
    return Category;
}());
exports.Category = Category;
//# sourceMappingURL=Category.js.map