import { Component } from '@angular/core';
import { Directive, OnInit, OnDestroy, Input } from '@angular/core';


import { CategoryService } from './service/category.service';

import { Config} from './model/Config';
import { Category} from './model/Category';

@Component({
  selector: 'app-category',
  templateUrl: './category.component.html', 
  providers: [ CategoryService ],
  styleUrls: ['./public/css/app.css']
})

export class CategoryComponent  implements OnInit  {
  error: any;
  headers: string[];
  config: Config;  
  newCategoryName:string;
  category=new Category("","");
  srchWorkoutTxt:string[];
  
  //categories:Category[];
  categories:Category[];
  
  constructor(private categoryService: CategoryService) {}
  
    
  ngOnInit() {		
	this.getAllCategories();
  }
  getAllCategories(): void {
	  this.categoryService.getAllCategories()
      .subscribe(categories => this.categories = categories);
  }
  
  //call service to list all available categories
  getAllCategoriesHttp(): void {
	  this.categoryService.getAllCategoriesHttp()
      .subscribe(categories => this.categories = categories);
  }
  //call service to update Category
  updateCategoryHttp(category:Category): void {
	console.log(category.categoryName);
	this.categoryService.updateCategory(category)
     .subscribe(() => console.log("go back"));
 }
 //call service to save new Category
 addCategoryHttp(){
	if(this.newCategoryName!=null && this.newCategoryName!=""){
	  this.category=new Category("",this.newCategoryName);	  
	  this.categoryService.saveCategory(this.category);
	  this.getAllCategories();
	  this.newCategoryName="";
	}
  }	
  deleteCategory(category:Category){
	console.log("Category ID Name To delete "+category.categoryId+" "+category.categoryName);
	//this.category = this.categories.filter(h => h !== category);
    this.categoryService.deleteCategory(category).subscribe();
  }
  
  
  updateCategory(category:Category): void {
	console.log(category.categoryName);	
  }  
  addCategory(){		
	if(this.newCategoryName!=null && this.newCategoryName!=""){
	  this.category=new Category("",this.newCategoryName);	  	  	  
	  this.newCategoryName="Added";
	}		
  }	  
  deleteCategoryH(categoryId:string){				
	this.newCategoryName=categoryId;	
  }	    

 
}