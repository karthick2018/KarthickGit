import { Component } from '@angular/core';
import { Directive, OnInit, OnDestroy, Input } from '@angular/core';
import { Router, ActivatedRoute, ParamMap } from '@angular/router';


import {Category} from './model/Category';
import {Workout} from './model/Workout';
import {WorkoutActive} from './model/WorkoutActive';

@Component({
  selector: 'app-root',
  templateUrl: './startEndWorkout.component.html',
  styleUrls: ['./public/css/app.css']
})
export class StartEndWorkComponent implements OnInit{
	
	value: Date;
    page:string;
	workoutActive=new WorkoutActive();
	
	constructor(private router: Router,private route: ActivatedRoute) {
		this.route.params.subscribe( params => console.log(params));
	}
	
	ngOnInit() {
		this.page = this.route.snapshot.paramMap.get('page');
		
		this.workoutActive.workoutTitle="Karthick";
		this.workoutActive.workoutComments="Karthick Notes";
		
		console.log("Id::::::: :"+this.page);
	}
	cancelWorkoutActive() {
        this.router.navigate(['/ViewAllWorkout']);
    }
	
	startEndWorkoutActive(){
		console.log("Page in to start end workout::::::: :"+this.page);		
		
	}

}